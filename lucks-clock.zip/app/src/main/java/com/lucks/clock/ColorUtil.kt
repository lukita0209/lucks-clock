package com.lucks.clock

import android.graphics.Bitmap
import android.graphics.Color

fun hex(v: Long): Int = v.toInt()

object ColorUtil {

    fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    fun mix(a: Int, b: Int, t: Float): Int {
        val f = t.coerceIn(0f, 1f)
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        return Color.rgb(r, g, bl)
    }

    fun isLight(c: Int): Boolean =
        (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.62

    fun darken(c: Int, f: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[2] = hsv[2] * f
        return Color.HSVToColor(hsv)
    }

    /** Color dominante de la portada: favorece los tonos saturados. */
    fun dominant(src: Bitmap): Int {
        val size = 32
        val bmp = Bitmap.createScaledBitmap(src, size, size, true)
        val px = IntArray(size * size)
        bmp.getPixels(px, 0, size, 0, 0, size, size)
        val w = FloatArray(512)
        val rs = FloatArray(512)
        val gs = FloatArray(512)
        val bs = FloatArray(512)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[2] < 0.1f) continue
            val wt = 0.2f + hsv[1] * 1.5f
            val k = ((Color.red(p) shr 5) shl 6) or ((Color.green(p) shr 5) shl 3) or (Color.blue(p) shr 5)
            w[k] += wt
            rs[k] += Color.red(p) * wt
            gs[k] += Color.green(p) * wt
            bs[k] += Color.blue(p) * wt
        }
        var best = -1
        var bw = 0f
        for (i in 0 until 512) {
            if (w[i] > bw) { bw = w[i]; best = i }
        }
        if (best < 0) return hex(0xFF2B2F3A)
        val c = Color.rgb((rs[best] / w[best]).toInt(), (gs[best] / w[best]).toInt(), (bs[best] / w[best]).toInt())
        Color.colorToHSV(c, hsv)
        hsv[2] = hsv[2].coerceIn(0.35f, 0.85f)
        return Color.HSVToColor(hsv)
    }
}
