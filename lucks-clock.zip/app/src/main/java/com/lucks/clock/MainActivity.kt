package com.lucks.clock

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.format.DateFormat
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val AMPM_SCALE = 0.3f

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var spotify: SpotifyBridge

    // ---- ajustes del usuario ----
    private var is24 = true
    private var fontIdx = 1
    private var bgColor = Color.BLACK
    private var fgColor = Color.WHITE
    private var shownBg = Color.BLACK
    private var shownFg = Color.WHITE

    private val fonts = listOf(
        "Fina" to "sans-serif-thin",
        "Ligera" to "sans-serif-light",
        "Clásica" to "sans-serif",
        "Condensada" to "sans-serif-condensed",
        "Gruesa" to "sans-serif-black",
        "Serif" to "serif",
        "Mono" to "monospace",
        "Manuscrita" to "cursive",
        "Casual" to "casual"
    )
    private val bgPalette = intArrayOf(
        hex(0xFF000000), hex(0xFF14161C), hex(0xFF0B1230), hex(0xFF1B0F33), hex(0xFF06231B),
        hex(0xFF2E0E18), hex(0xFF2B1B10), hex(0xFF0D47A1), hex(0xFFF5EFE0), hex(0xFFFFFFFF)
    )
    private val fgPalette = intArrayOf(
        hex(0xFFFFFFFF), hex(0xFFF3E9D2), hex(0xFF4DD0E1), hex(0xFF69F0AE), hex(0xFFFFC107),
        hex(0xFFFF7043), hex(0xFFFF4081), hex(0xFFB388FF), hex(0xFFFF5252), hex(0xFF000000)
    )

    // ---- vistas: reloj ----
    private lateinit var root: FrameLayout
    private lateinit var clockBox: LinearLayout
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var secBar: View
    private lateinit var gearBtn: ImageView
    private lateinit var gearBg: GradientDrawable

    // ---- vistas: música ----
    private lateinit var musicWrap: FrameLayout
    private lateinit var musicIcon: ImageView
    private lateinit var musicBg: GradientDrawable
    private lateinit var pulse: View
    private lateinit var pulseBg: GradientDrawable
    private lateinit var card: LinearLayout
    private lateinit var cardBg: GradientDrawable
    private lateinit var cover: ImageView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var elapsedTv: TextView
    private lateinit var totalTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var shuffleBtn: ImageView
    private lateinit var repeatBtn: ImageView
    private lateinit var playBtn: ImageView
    private lateinit var prevBtn: ImageView
    private lateinit var nextBtn: ImageView
    private lateinit var playBg: GradientDrawable
    private lateinit var collapseBtn: ImageView

    // ---- vistas: ajustes ----
    private lateinit var settingsLayer: FrameLayout
    private lateinit var scrim: View
    private lateinit var panel: LinearLayout
    private val updaters = mutableListOf<() -> Unit>()

    // ---- estado ----
    private var fitKey = ""
    private var lastDate = ""
    private var expanded = false
    private var musicShown = false
    private var settingsOpen = false
    private var seeking = false
    private var holdUntil = 0L
    private var shuffleOn = false
    private var repeatMode = 0
    private var cardColor = hex(0xFF1DB954)
    private var cardAnim: ValueAnimator? = null
    private var lastCoverVer = -1
    private var lastTrackKey = ""
    private var lastPlayRes = 0

    private fun Int.dp(): Int = (this * resources.displayMetrics.density + 0.5f).toInt()

    private val dateFmt by lazy {
        SimpleDateFormat(DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM"), Locale.getDefault())
    }

    // =====================================================================
    // Ciclo de vida
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("lucks", MODE_PRIVATE)
        is24 = prefs.getBoolean("is24", true)
        fontIdx = prefs.getInt("font", 1).coerceIn(0, fonts.size - 1)
        bgColor = prefs.getInt("bg", Color.BLACK)
        fgColor = prefs.getInt("fg", Color.WHITE)
        shownBg = bgColor
        shownFg = fgColor

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        setContentView(root)
        setupWindow()

        paint(bgColor, fgColor)
        clockText.typeface = face(fontIdx)
        dateText.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        pop(clockText)

        spotify = SpotifyBridge(this) { refreshMusic() }
        try {
            if (listenerEnabled()) {
                NotificationListenerService.requestRebind(ComponentName(this, MediaListener::class.java))
            }
        } catch (e: Exception) {
        }
        revealControls()
    }

    override fun onResume() {
        super.onResume()
        setupWindow()
        ui.removeCallbacks(tick)
        ui.post(tick)
        spotify.start()
        refreshMusic()
        syncSettings()
        ui.removeCallbacks(retryStart)
        ui.postDelayed(retryStart, 1500)
        if (expanded) {
            ui.removeCallbacks(progressLoop)
            ui.post(progressLoop)
        }
        if (!listenerEnabled() && !prefs.getBoolean("asked", false)) {
            prefs.edit().putBoolean("asked", true).apply()
            showPermDialog()
        }
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(progressLoop)
        ui.removeCallbacks(retryStart)
        if (pulseAnim.isRunning) pulseAnim.cancel()
        spotify.stop()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setupWindow()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            settingsOpen -> closeSettings()
            expanded -> collapseMusic()
            else -> super.onBackPressed()
        }
    }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    // =====================================================================
    // Construcción de la interfaz
    // =====================================================================

    private fun face(i: Int): Typeface = Typeface.create(fonts[i].second, Typeface.NORMAL)

    private fun round(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp.dp().toFloat()
    }

    private fun View.pressFx() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun pop(v: View) {
        v.scaleX = 0.88f
        v.scaleY = 0.88f
        v.alpha = 0f
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setOnClickListener { revealControls() }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitClock() }

        // barra fina de segundos arriba
        secBar = View(this)
        root.addView(secBar, FrameLayout.LayoutParams(MATCH, 3.dp(), Gravity.TOP))
        secBar.pivotX = 0f
        secBar.scaleX = 0f

        // reloj + fecha
        clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        clockText = TextView(this).apply {
            includeFontPadding = false
            gravity = Gravity.CENTER
            maxLines = 1
        }
        dateText = TextView(this).apply {
            gravity = Gravity.CENTER
            alpha = 0.7f
        }
        clockBox.addView(clockText, LinearLayout.LayoutParams(WRAP, WRAP))
        clockBox.addView(dateText, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = 6.dp() })
        root.addView(clockBox, FrameLayout.LayoutParams(MATCH, MATCH))

        buildMusic()

        // botón de ajustes (se esconde solo)
        gearBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        gearBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_tune)
            background = gearBg
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
            pressFx()
            setOnClickListener { if (alpha < 0.3f) revealControls() else openSettings() }
        }
        root.addView(gearBtn, FrameLayout.LayoutParams(48.dp(), 48.dp(), Gravity.TOP or Gravity.END).apply {
            topMargin = 14.dp()
            rightMargin = 40.dp()
        })

        buildSettings()
    }

    private fun buildMusic() {
        // icono redondo de música
        pulseBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        pulse = View(this).apply {
            background = pulseBg
            alpha = 0f
        }
        musicBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        musicIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_music)
            background = musicBg
            setPadding(16.dp(), 16.dp(), 16.dp(), 16.dp())
            pressFx()
            setOnClickListener { expandMusic() }
        }
        musicWrap = FrameLayout(this).apply { visibility = View.GONE }
        musicWrap.addView(pulse, FrameLayout.LayoutParams(60.dp(), 60.dp(), Gravity.CENTER))
        musicWrap.addView(musicIcon, FrameLayout.LayoutParams(60.dp(), 60.dp(), Gravity.CENTER))
        root.addView(musicWrap, FrameLayout.LayoutParams(
            84.dp(), 84.dp(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = 10.dp() })

        // tarjeta del reproductor
        cardBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cardColor, cardColor)).apply {
            cornerRadius = 28.dp().toFloat()
        }
        card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg
            elevation = 14.dp().toFloat()
            isClickable = true
            setPadding(14.dp(), 14.dp(), 14.dp(), 14.dp())
            visibility = View.GONE
        }

        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 18.dp().toFloat())
                }
            }
        }
        card.addView(cover, LinearLayout.LayoutParams(104.dp(), 104.dp()))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        titleTv = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        collapseBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_expand)
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            pressFx()
            setOnClickListener { collapseMusic() }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(collapseBtn, LinearLayout.LayoutParams(34.dp(), 34.dp()))

        artistTv = TextView(this).apply {
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            alpha = 0.75f
        }

        elapsedTv = TextView(this).apply { textSize = 12f; text = "0:00" }
        totalTv = TextView(this).apply { textSize = 12f; text = "0:00" }
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) elapsedTv.text = fmt(p.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                holdUntil = SystemClock.elapsedRealtime() + 900
                spotify.seekTo((sb?.progress ?: 0).toLong())
            }
        })
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(elapsedTv)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        seekRow.addView(totalTv)

        shuffleBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_shuffle)
            setPadding(9.dp(), 9.dp(), 9.dp(), 9.dp())
            pressFx()
            setOnClickListener {
                shuffleOn = !shuffleOn
                spotify.setShuffle(shuffleOn)
                updateModeButtons()
            }
        }
        repeatBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_repeat)
            setPadding(9.dp(), 9.dp(), 9.dp(), 9.dp())
            pressFx()
            setOnClickListener {
                repeatMode = (repeatMode + 1) % 3
                spotify.setRepeat(repeatMode)
                updateModeButtons()
            }
        }
        playBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        playBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            background = playBg
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
            pressFx()
            setOnClickListener { spotify.togglePlay() }
        }
        prevBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_prev)
            setPadding(7.dp(), 7.dp(), 7.dp(), 7.dp())
            pressFx()
            setOnClickListener { spotify.skipPrev() }
        }
        nextBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_next)
            setPadding(7.dp(), 7.dp(), 7.dp(), 7.dp())
            pressFx()
            setOnClickListener { spotify.skipNext() }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(shuffleBtn, LinearLayout.LayoutParams(40.dp(), 40.dp()))
        controls.addView(prevBtn, LinearLayout.LayoutParams(42.dp(), 42.dp()).apply {
            leftMargin = 10.dp()
        })
        controls.addView(playBtn, LinearLayout.LayoutParams(50.dp(), 50.dp()).apply {
            leftMargin = 10.dp()
            rightMargin = 10.dp()
        })
        controls.addView(nextBtn, LinearLayout.LayoutParams(42.dp(), 42.dp()).apply {
            rightMargin = 10.dp()
        })
        controls.addView(repeatBtn, LinearLayout.LayoutParams(40.dp(), 40.dp()))

        right.addView(head)
        right.addView(artistTv)
        right.addView(seekRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 2.dp() })
        right.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(right, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = 16.dp() })

        root.addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            leftMargin = 40.dp()
            rightMargin = 40.dp()
            bottomMargin = 14.dp()
        })

        applyCardFg(Color.WHITE, cardColor)
        updateModeButtons()
        setCover(null)
    }

    // =====================================================================
    // Reloj
    // =====================================================================

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            ui.postDelayed(this, 1000L - (System.currentTimeMillis() % 1000L) + 8L)
        }
    }

    private fun updateClock() {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val s = c.get(Calendar.SECOND)
        val txt: CharSequence = if (is24) {
            String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        } else {
            val h12 = if (h % 12 == 0) 12 else h % 12
            val main = String.format(Locale.US, "%d:%02d:%02d", h12, m, s)
            val sp = SpannableString(main + " " + (if (h < 12) "AM" else "PM"))
            sp.setSpan(RelativeSizeSpan(AMPM_SCALE), main.length, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sp
        }
        clockText.text = txt

        val d = dateFmt.format(c.time)
        if (d != lastDate) {
            lastDate = d
            dateText.text = d.replaceFirstChar { it.uppercase() }
        }

        secBar.animate().cancel()
        secBar.scaleX = s / 60f
        secBar.animate().scaleX((s + 1) / 60f).setDuration(1000).setInterpolator(LinearInterpolator()).start()
    }

    /** Calcula un tamaño fijo para que "88:88:88" llene el ancho sin saltos entre segundos. */
    private fun fitClock() {
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0) return
        val key = "$w x $h $fontIdx $is24"
        if (key == fitKey) return
        fitKey = key
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = face(fontIdx)
        p.textSize = 100f
        var w0 = p.measureText("88:88:88")
        if (!is24) w0 += p.measureText(" MM") * AMPM_SCALE
        val fm = p.fontMetrics
        val h0 = fm.descent - fm.ascent
        val availW = (w - 2 * 48.dp()) * 0.96f
        val availH = h * 0.58f
        val size = minOf(availW / w0 * 100f, availH / h0 * 100f)
        clockText.setTextSize(TypedValue.COMPLEX_UNIT_PX, size)
        dateText.setTextSize(
            TypedValue.COMPLEX_UNIT_PX,
            (size * 0.11f).coerceIn(14.dp().toFloat(), 30.dp().toFloat())
        )
    }

    private val hideGear = Runnable { gearBtn.animate().alpha(0f).setDuration(500).start() }

    private fun revealControls() {
        if (settingsOpen) return
        gearBtn.animate().alpha(1f).setDuration(200).start()
        ui.removeCallbacks(hideGear)
        ui.postDelayed(hideGear, 4000)
    }

    // =====================================================================
    // Colores / tema
    // =====================================================================

    private fun applyTheme() {
        val bf = shownBg
        val ff = shownFg
        shownBg = bgColor
        shownFg = fgColor
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            addUpdateListener {
                val t = it.animatedFraction
                paint(ColorUtil.mix(bf, bgColor, t), ColorUtil.mix(ff, fgColor, t))
            }
            start()
        }
    }

    private fun paint(bg: Int, fg: Int) {
        root.setBackgroundColor(bg)
        clockText.setTextColor(fg)
        dateText.setTextColor(fg)
        secBar.setBackgroundColor(ColorUtil.alpha(fg, 120))
        gearBtn.setColorFilter(fg)
        gearBg.setColor(ColorUtil.alpha(fg, 38))
        musicIcon.setColorFilter(fg)
        musicBg.setColor(ColorUtil.alpha(fg, 46))
        pulseBg.setColor(ColorUtil.alpha(fg, 90))
    }

    private fun clockSettingChanged() {
        fitKey = ""
        clockText.typeface = face(fontIdx)
        fitClock()
        updateClock()
        pop(clockText)
        syncSettings()
    }

    // =====================================================================
    // Música
    // =====================================================================

    private val retryStart = Runnable { if (!spotify.active) spotify.start() }

    private val pulseAnim: ValueAnimator by lazy {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1700
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedFraction
                pulse.scaleX = 1f + 0.5f * f
                pulse.scaleY = 1f + 0.5f * f
                pulse.alpha = 0.6f * (1f - f)
            }
        }
    }

    private fun updatePulse() {
        val want = musicShown && spotify.playing
        if (want && !pulseAnim.isRunning) {
            pulseAnim.start()
        } else if (!want && pulseAnim.isRunning) {
            pulseAnim.cancel()
            pulse.alpha = 0f
            pulse.scaleX = 1f
            pulse.scaleY = 1f
        }
    }

    private fun refreshMusic() {
        if (!spotify.active) {
            if (expanded) collapseMusic()
            showMusicBtn(false)
            updatePulse()
            return
        }
        if (!expanded) showMusicBtn(true)

        val key = spotify.title + "\u0000" + spotify.artist
        if (key != lastTrackKey) {
            lastTrackKey = key
            swapText(titleTv, spotify.title, 1f)
            swapText(artistTv, spotify.artist, 0.75f)
        }
        if (spotify.coverVersion != lastCoverVer) {
            lastCoverVer = spotify.coverVersion
            val bmp = spotify.cover
            setCover(bmp)
            setCardColor(if (bmp != null) ColorUtil.dominant(bmp) else hex(0xFF2B2F3A))
        }
        val res = if (spotify.playing) R.drawable.ic_pause else R.drawable.ic_play
        if (res != lastPlayRes) {
            lastPlayRes = res
            playBtn.setImageResource(res)
            if (expanded) pop(playBtn)
        }
        updateProgress()
        updatePulse()
    }

    private fun swapText(tv: TextView, text: String, targetAlpha: Float) {
        tv.text = text
        tv.alpha = 0f
        tv.translationY = 8.dp().toFloat()
        tv.animate().alpha(targetAlpha).translationY(0f).setDuration(350).start()
    }

    private fun setCover(bmp: Bitmap?) {
        if (bmp != null) {
            cover.clearColorFilter()
            cover.setPadding(0, 0, 0, 0)
            cover.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.setBackgroundColor(0)
            cover.setImageBitmap(bmp)
        } else {
            cover.setImageResource(R.drawable.ic_music)
            cover.scaleType = ImageView.ScaleType.CENTER_INSIDE
            cover.setPadding(28.dp(), 28.dp(), 28.dp(), 28.dp())
            cover.setColorFilter(hex(0xCCFFFFFF))
            cover.setBackgroundColor(hex(0x33000000))
        }
        cover.alpha = 0f
        cover.scaleX = 0.9f
        cover.scaleY = 0.9f
        cover.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun setCardColor(target: Int) {
        val from = cardColor
        cardColor = target
        val fg = if (ColorUtil.isLight(target)) hex(0xFF111111) else Color.WHITE
        applyCardFg(fg, target)
        cardAnim?.cancel()
        if (card.visibility != View.VISIBLE) {
            applyCardBg(target)
            return
        }
        cardAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener { applyCardBg(ColorUtil.mix(from, target, it.animatedFraction)) }
            start()
        }
    }

    private fun applyCardBg(c: Int) {
        cardBg.setColors(intArrayOf(c, ColorUtil.darken(c, 0.7f)))
    }

    private fun applyCardFg(fg: Int, base: Int) {
        titleTv.setTextColor(fg)
        artistTv.setTextColor(fg)
        elapsedTv.setTextColor(fg)
        totalTv.setTextColor(fg)
        seek.progressTintList = ColorStateList.valueOf(fg)
        seek.thumbTintList = ColorStateList.valueOf(fg)
        seek.progressBackgroundTintList = ColorStateList.valueOf(ColorUtil.alpha(fg, 70))
        shuffleBtn.setColorFilter(fg)
        repeatBtn.setColorFilter(fg)
        collapseBtn.setColorFilter(fg)
        prevBtn.setColorFilter(fg)
        nextBtn.setColorFilter(fg)
        playBg.setColor(fg)
        playBtn.setColorFilter(if (fg == Color.WHITE) ColorUtil.darken(base, 0.55f) else Color.WHITE)
    }

    private fun updateModeButtons() {
        shuffleBtn.alpha = if (shuffleOn) 1f else 0.4f
        repeatBtn.setImageResource(if (repeatMode == 2) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatBtn.alpha = if (repeatMode == 0) 0.4f else 1f
    }

    private fun showMusicBtn(show: Boolean) {
        if (show == musicShown) return
        musicShown = show
        musicWrap.animate().cancel()
        if (show) {
            musicWrap.visibility = View.VISIBLE
            musicWrap.scaleX = 0f
            musicWrap.scaleY = 0f
            musicWrap.alpha = 0f
            musicWrap.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(450)
                .setInterpolator(OvershootInterpolator(1.8f)).start()
        } else {
            musicWrap.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(250)
                .withEndAction { if (!musicShown) musicWrap.visibility = View.GONE }.start()
        }
        updatePulse()
    }

    private fun whenLaidOut(v: View, block: () -> Unit) {
        if (v.isLaidOut && v.height > 0) {
            block()
            return
        }
        v.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                view: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, orr: Int, ob: Int
            ) {
                if (view.height > 0) {
                    view.removeOnLayoutChangeListener(this)
                    block()
                }
            }
        })
    }

    private fun expandMusic() {
        if (expanded) return
        expanded = true
        showMusicBtn(false)
        card.animate().cancel()
        card.alpha = 0f
        card.visibility = View.VISIBLE
        applyCardBg(cardColor)
        whenLaidOut(card) {
            if (expanded) {
                card.translationY = (card.height + 40.dp()).toFloat()
                card.animate().translationY(0f).alpha(1f).setDuration(520)
                    .setInterpolator(DecelerateInterpolator(2.2f)).start()
                val shift = -(card.height + 14.dp()) / 2f
                clockBox.animate().cancel()
                clockBox.animate().scaleX(0.55f).scaleY(0.55f).translationY(shift).setDuration(560)
                    .setInterpolator(DecelerateInterpolator(2.2f)).start()
            }
        }
        updateProgress()
        ui.removeCallbacks(progressLoop)
        ui.post(progressLoop)
    }

    private fun collapseMusic() {
        if (!expanded) return
        expanded = false
        ui.removeCallbacks(progressLoop)
        card.animate().cancel()
        card.animate().translationY((card.height + 40.dp()).toFloat()).alpha(0f).setDuration(340)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { if (!expanded) card.visibility = View.GONE }.start()
        clockBox.animate().cancel()
        clockBox.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(460)
            .setInterpolator(DecelerateInterpolator(2.2f)).start()
        if (spotify.active) showMusicBtn(true)
    }

    private val progressLoop = object : Runnable {
        override fun run() {
            updateProgress()
            if (expanded) ui.postDelayed(this, 400)
        }
    }

    private fun updateProgress() {
        if (seeking || SystemClock.elapsedRealtime() < holdUntil) return
        val d = spotify.duration.coerceIn(0L, Int.MAX_VALUE.toLong())
        val p = if (d > 0) spotify.position().coerceIn(0L, d) else 0L
        if (seek.max != d.toInt()) seek.max = d.toInt()
        seek.setProgress(p.toInt(), true)
        elapsedTv.text = fmt(p)
        totalTv.text = if (d > 0) fmt(d) else "--:--"
        seek.isEnabled = d > 0
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    // =====================================================================
    // Panel de ajustes
    // =====================================================================

    private fun syncSettings() {
        updaters.forEach { it() }
    }

    private fun buildSettings() {
        settingsLayer = FrameLayout(this).apply { visibility = View.GONE }
        scrim = View(this).apply {
            setBackgroundColor(hex(0x99000000))
            setOnClickListener { closeSettings() }
        }
        settingsLayer.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        val pw = minOf((resources.displayMetrics.widthPixels * 0.55f).toInt(), 440.dp())
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(hex(0xF2171A21), 26)
            elevation = 20.dp().toFloat()
            isClickable = true
        }

        // cabecera
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22.dp(), 14.dp(), 12.dp(), 0)
        }
        val title = TextView(this).apply {
            text = "Ajustes"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.WHITE)
            setPadding(10.dp(), 10.dp(), 10.dp(), 10.dp())
            pressFx()
            setOnClickListener { closeSettings() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(close, LinearLayout.LayoutParams(44.dp(), 44.dp()))
        panel.addView(header)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 0, 22.dp(), 22.dp())
        }
        body.addView(label("Formato de hora"))
        body.addView(segmented(listOf("24 h", "12 h"), { if (is24) 0 else 1 }) { i ->
            is24 = i == 0
            prefs.edit().putBoolean("is24", is24).apply()
            clockSettingChanged()
        })
        body.addView(label("Fuente"))
        body.addView(fontChips())
        body.addView(label("Color de fondo"))
        body.addView(swatches(bgPalette, { bgColor }) {
            bgColor = it
            prefs.edit().putInt("bg", it).apply()
            applyTheme()
            syncSettings()
        })
        body.addView(label("Color del texto"))
        body.addView(swatches(fgPalette, { fgColor }) {
            fgColor = it
            prefs.edit().putInt("fg", it).apply()
            applyTheme()
            syncSettings()
        })
        body.addView(label("Spotify"))
        body.addView(spotifyRow())

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        scroll.addView(body)
        panel.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        settingsLayer.addView(panel, FrameLayout.LayoutParams(pw, MATCH, Gravity.END).apply {
            topMargin = 10.dp()
            bottomMargin = 10.dp()
            rightMargin = 14.dp()
        })
        root.addView(settingsLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(hex(0xFF9AA3B5))
        letterSpacing = 0.04f
        setPadding(0, 18.dp(), 0, 8.dp())
    }

    private fun segmented(opts: List<String>, selected: () -> Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(hex(0x1FFFFFFF), 22)
            setPadding(4.dp(), 4.dp(), 4.dp(), 4.dp())
        }
        val tvs = opts.mapIndexed { i, s ->
            TextView(this).apply {
                text = s
                gravity = Gravity.CENTER
                textSize = 15f
                setPadding(0, 10.dp(), 0, 10.dp())
                setOnClickListener { onPick(i) }
            }
        }
        tvs.forEach { row.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f)) }
        val upd = {
            tvs.forEachIndexed { i, tv ->
                val on = i == selected()
                tv.background = round(if (on) Color.WHITE else 0, 18)
                tv.setTextColor(if (on) hex(0xFF111111) else Color.WHITE)
            }
        }
        updaters.add(upd)
        upd()
        return row
    }

    private fun fontChips(): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hs.addView(row)
        val tvs = fonts.mapIndexed { i, f ->
            TextView(this).apply {
                text = f.first
                typeface = face(i)
                textSize = 17f
                setPadding(18.dp(), 10.dp(), 18.dp(), 10.dp())
                setOnClickListener {
                    fontIdx = i
                    prefs.edit().putInt("font", i).apply()
                    clockSettingChanged()
                }
            }
        }
        tvs.forEach { row.addView(it, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = 8.dp() }) }
        val upd = {
            tvs.forEachIndexed { i, tv ->
                val on = i == fontIdx
                tv.background = round(if (on) Color.WHITE else hex(0x24FFFFFF), 20)
                tv.setTextColor(if (on) hex(0xFF111111) else Color.WHITE)
            }
        }
        updaters.add(upd)
        upd()
        return hs
    }

    private fun swatches(palette: IntArray, current: () -> Int, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(2.dp(), 4.dp(), 2.dp(), 4.dp())
        }
        hs.addView(row)
        val items = ArrayList<Triple<GradientDrawable, ImageView, Int>>()
        val ringOff = hex(0x66FFFFFF)

        fun checkView(tint: Int) = ImageView(this).apply {
            setImageResource(R.drawable.ic_check)
            setColorFilter(tint)
            setPadding(10.dp(), 10.dp(), 10.dp(), 10.dp())
            visibility = View.INVISIBLE
        }

        for (c in palette) {
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(2.dp(), ringOff)
            }
            val check = checkView(if (ColorUtil.isLight(c)) hex(0xFF111111) else Color.WHITE)
            val cell = FrameLayout(this).apply {
                background = bg
                setOnClickListener { onPick(c) }
            }
            cell.addView(check, FrameLayout.LayoutParams(MATCH, MATCH))
            row.addView(cell, LinearLayout.LayoutParams(42.dp(), 42.dp()).apply { rightMargin = 10.dp() })
            items.add(Triple(bg, check, c))
        }

        // color personalizado (HEX)
        val rainbow = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.SWEEP_GRADIENT
            setColors(intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED))
            setStroke(2.dp(), ringOff)
        }
        val customCheck = checkView(Color.WHITE)
        val customCell = FrameLayout(this).apply {
            background = rainbow
            setOnClickListener { askHex(current(), onPick) }
        }
        customCell.addView(customCheck, FrameLayout.LayoutParams(MATCH, MATCH))
        row.addView(customCell, LinearLayout.LayoutParams(42.dp(), 42.dp()))

        val upd = {
            val cur = current()
            items.forEach { (bg, ck, c) ->
                val on = c == cur
                ck.visibility = if (on) View.VISIBLE else View.INVISIBLE
                bg.setStroke(if (on) 3.dp() else 2.dp(), if (on) Color.WHITE else ringOff)
            }
            customCheck.visibility = if (palette.any { it == cur }) View.INVISIBLE else View.VISIBLE
        }
        updaters.add(upd)
        upd()
        return hs
    }

    private fun askHex(cur: Int, onOk: (Int) -> Unit) {
        val et = EditText(this)
        et.setText(String.format("#%06X", cur and 0xFFFFFF))
        et.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle("Color personalizado (HEX)")
            .setView(et)
            .setPositiveButton("Aplicar") { _, _ ->
                try {
                    var s = et.text.toString().trim()
                    if (!s.startsWith("#")) s = "#$s"
                    onOk(Color.parseColor(s))
                } catch (e: Exception) {
                    Toast.makeText(this, "Color inválido. Ejemplo: #FF8800", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun spotifyRow(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = TextView(this).apply {
            textSize = 13f
            setTextColor(hex(0xFFD5DAE5))
        }
        val btn = TextView(this).apply {
            text = "Abrir permisos de notificaciones"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = round(hex(0x30FFFFFF), 20)
            setPadding(16.dp(), 11.dp(), 16.dp(), 11.dp())
            pressFx()
            setOnClickListener { openListenerSettings() }
        }
        box.addView(status)
        box.addView(btn, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = 10.dp() })
        updaters.add {
            status.text = if (listenerEnabled()) {
                "Conectado. Pon una canción en Spotify y aparecerá el icono de música."
            } else {
                "Falta el acceso a notificaciones para poder leer Spotify."
            }
        }
        return box
    }

    private fun openSettings() {
        if (settingsOpen) return
        settingsOpen = true
        syncSettings()
        ui.removeCallbacks(hideGear)
        gearBtn.animate().alpha(0f).setDuration(150).start()
        settingsLayer.visibility = View.VISIBLE
        scrim.animate().cancel()
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(260).start()
        val off = (panel.layoutParams.width + 40.dp()).toFloat()
        panel.animate().cancel()
        panel.translationX = off
        panel.animate().translationX(0f).setDuration(400)
            .setInterpolator(DecelerateInterpolator(2.2f)).start()
    }

    private fun closeSettings() {
        if (!settingsOpen) return
        settingsOpen = false
        scrim.animate().alpha(0f).setDuration(220).start()
        panel.animate().translationX((panel.layoutParams.width + 40.dp()).toFloat()).setDuration(260)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { if (!settingsOpen) settingsLayer.visibility = View.GONE }.start()
        revealControls()
    }

    // =====================================================================
    // Permisos de Spotify
    // =====================================================================

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun openListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun showPermDialog() {
        AlertDialog.Builder(this)
            .setTitle("Conecta Spotify")
            .setMessage(
                "Para mostrar la canción que suena, Lucks Clock necesita acceso a las notificaciones. " +
                    "Activa \"Lucks Clock\" en la lista.\n\n" +
                    "Si aparece bloqueado: Info de la app > menú ⋮ > Permitir ajustes restringidos, y vuelve a intentar."
            )
            .setPositiveButton("Abrir ajustes") { _, _ -> openListenerSettings() }
            .setNeutralButton("Info de la app") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Luego", null)
            .show()
    }
}
