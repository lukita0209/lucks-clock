package com.lucks.clock

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío: su único trabajo es que Android nos dé acceso a las
 * sesiones de medios (lo que suena en Spotify) cuando el usuario lo permite.
 */
class MediaListener : NotificationListenerService()
