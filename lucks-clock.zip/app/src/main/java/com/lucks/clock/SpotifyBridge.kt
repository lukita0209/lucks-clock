package com.lucks.clock

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.SystemClock

/**
 * Lee y controla la sesión de medios de Spotify.
 * Requiere que el usuario active "Acceso a notificaciones" para Lucks Clock.
 */
class SpotifyBridge(ctx: Context, private val onChange: () -> Unit) {

    private val manager = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val component = ComponentName(ctx, MediaListener::class.java)
    private var controller: MediaController? = null
    private var listening = false
    private var trackKey = ""

    var title = ""
        private set
    var artist = ""
        private set
    var cover: Bitmap? = null
        private set
    var coverVersion = 0
        private set
    var duration = 0L
        private set
    var playing = false
        private set
    var active = false
        private set

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readState()
            onChange()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMeta(metadata)
            readState()
            onChange()
        }

        override fun onSessionDestroyed() {
            pick(sessions())
        }
    }

    private fun sessions(): List<MediaController>? =
        try {
            manager.getActiveSessions(component)
        } catch (e: SecurityException) {
            null
        }

    fun start() {
        stop()
        listening = try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, component)
            true
        } catch (e: SecurityException) {
            false
        }
        pick(sessions())
    }

    fun stop() {
        if (listening) {
            try {
                manager.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
            }
            listening = false
        }
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.packageName in PACKAGES }
        if (c?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = c
            c?.registerCallback(callback)
        }
        readMeta(c?.metadata)
        readState()
        onChange()
    }

    private fun readMeta(m: MediaMetadata?) {
        title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        duration = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val key = "$title|$artist"
        if (key != trackKey || (cover == null) != (bmp == null)) {
            trackKey = key
            coverVersion++
        }
        cover = bmp
    }

    private fun readState() {
        val st = controller?.playbackState?.state ?: PlaybackState.STATE_NONE
        playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
        active = controller != null && title.isNotEmpty() &&
            (playing || st == PlaybackState.STATE_PAUSED)
    }

    /** Posición actual en ms, calculada con el reloj para que avance suave. */
    fun position(): Long {
        val s = controller?.playbackState ?: return 0L
        var p = s.position
        if (s.state == PlaybackState.STATE_PLAYING) {
            p += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
        }
        return if (duration > 0) p.coerceIn(0L, duration) else p.coerceAtLeast(0L)
    }

    fun togglePlay() {
        val t = controller?.transportControls ?: return
        if (playing) t.pause() else t.play()
    }

    fun skipNext() {
        controller?.transportControls?.skipToNext()
    }

    fun skipPrev() {
        controller?.transportControls?.skipToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.transportControls?.seekTo(ms)
    }

    private fun customAction(word: String): PlaybackState.CustomAction? =
        controller?.playbackState?.customActions?.firstOrNull {
            (it.action ?: "").contains(word, true) || (it.name?.toString() ?: "").contains(word, true)
        }

    /** Shuffle: usa la acción propia de Spotify si existe; si no, la acción estándar. */
    fun setShuffle(on: Boolean) {
        val t = controller?.transportControls ?: return
        val ca = customAction("shuffle")
        if (ca != null) {
            t.sendCustomAction(ca, null)
        } else {
            t.sendCustomAction(ACTION_SHUFFLE, Bundle().apply { putInt(ARG_SHUFFLE, if (on) 1 else 0) })
        }
    }

    /** mode de la UI: 0 = no, 1 = todas, 2 = una canción. */
    fun setRepeat(mode: Int) {
        val t = controller?.transportControls ?: return
        val ca = customAction("repeat")
        if (ca != null) {
            t.sendCustomAction(ca, null)
        } else {
            val compat = when (mode) { 1 -> 2; 2 -> 1; else -> 0 }
            t.sendCustomAction(ACTION_REPEAT, Bundle().apply { putInt(ARG_REPEAT, compat) })
        }
    }

    companion object {
        private val PACKAGES = setOf("com.spotify.music", "com.spotify.lite")
        private const val ACTION_SHUFFLE = "android.support.v4.media.session.action.SET_SHUFFLE_MODE"
        private const val ARG_SHUFFLE = "android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE"
        private const val ACTION_REPEAT = "android.support.v4.media.session.action.SET_REPEAT_MODE"
        private const val ARG_REPEAT = "android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE"
    }
}
